#maybe sparse pca

allpca = princomp(affy_exp, center=TRUE, scale.=TRUE)

