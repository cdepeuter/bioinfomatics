ColourScale <- 'd3.scale.ordinal()
            .rank(pct_diffexp)/max(rank(pct_diffexp))
.range(["#FF6900", "#694489"]);'
JS(ColourScale)